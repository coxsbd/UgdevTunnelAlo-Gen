package com.dynamic.vpn.gen.listener;

import org.json.JSONObject;

public interface SpinnerListener {
	void onAdd(JSONObject json);
}
