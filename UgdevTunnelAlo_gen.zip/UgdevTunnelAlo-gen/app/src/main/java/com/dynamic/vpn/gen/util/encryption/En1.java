package com.dynamic.vpn.gen.util.encryption;

public interface En1 {
    String encryptString(String string, int key);
}
