package com.dynamic.vpn.gen.util.decryption;

public interface De1 {
    String decryptString(String string, int key);
}
