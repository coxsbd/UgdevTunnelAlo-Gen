package com.dynamic.vpn.gen.util;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.dynamic.vpn.gen.R;


public class Decrytion extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback, View.OnClickListener {
    private Toolbar tb;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_dialog);

        Button encryptBtn, decryptBtn;
        encryptBtn = findViewById(R.id.encryptBtn);
        decryptBtn = findViewById(R.id.decryptBtn);
       // encryptET.setText("4861726R6965735E484A47656I5E4L6E6I5E4170725E31315E32303232");
        EditText encryptET, decryptET;
        encryptET = findViewById(R.id.encryptET);
        decryptET = findViewById(R.id.decryptET);

        encryptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String encryptedText = BED.En(encryptET.getText().toString(),FileUtil.tostring(BED.a));
                decryptET.setText(encryptedText);
            }
        });

        decryptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String decryptedText = BED.De(decryptET.getText().toString(), FileUtil.tostring(BED.a));
                    encryptET.setText(decryptedText);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void onClick(View view) {

    }
}