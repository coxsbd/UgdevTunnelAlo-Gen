package com.dynamic.vpn.gen;

import android.content.*;
import android.os.*;
import android.graphics.*;
import android.widget.Button;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.EditText;
import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;

import com.dynamic.vpn.gen.util.BED;
import com.dynamic.vpn.gen.util.DataBaseHelper;
import com.dynamic.vpn.gen.util.FileUtil;

public class LauncherActivity extends AppCompatActivity
{
    private DataBaseHelper ServerData,HTTPData,SSLData;
    private EditText KeyGen;

    public SharedPreferences mPref;

    String userpassword="ugandadev";
    public static final String CONFIG_GET_API = "https://ugandadev.uk/uploads/json/a22cf1d7d29c7f43bd48.json";
    public static final String CONFIG_POST_API = "https://ugandadev.uk/api/edit.php";

    static void setStatusBarColor(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.BLACK);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBarColor(this);
        setContentView(R.layout.activity_login);
        ServerData = new DataBaseHelper(this,"ServerData");
        HTTPData = new DataBaseHelper(this,"HTTPData");
        SSLData = new DataBaseHelper(this,"SSLData");
        mPref = getSharedPreferences("mKEYGEN", MODE_PRIVATE);
        Boolean.parseBoolean("firstStart");{
            try{
                ServerData.insertData("[]");
                HTTPData.insertData("[]");
                SSLData.insertData("[]");
                mPref.edit().putBoolean("firstStart", false).apply();
            }catch (Exception ignored)
            {}
        }
        // layoutPassCode = findViewById(R.id.splashTextInputEditText1);
        KeyGen = findViewById(R.id.admin_login);
        /* final Button encrypt = findViewById(R.id.encrypt2);*/
        final Button login = findViewById(R.id.loginBtn);
        KeyGen.setText(mPref.getString("_mKeyGen", ""));
        KeyGen.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String kg = KeyGen.getText().toString().trim();
                mPref.edit().putString("_mKeyGen",kg).apply();
                if (kg.length() <= 31) {
                    KeyGen.setTextColor(Color.RED);
                    KeyGen.setError("Enter a Valid PassCode");
                    //  layoutPassCode.setErrorEnabled(true);
                    //layoutPassCode.setError("PassCode should be Greater than 32 characters");
                } else {
                    KeyGen.setTextColor(Color.GREEN);
                    //layoutPassCode.setErrorEnabled(false);
                    try {
                        if(BED.De(KeyGen.getText().toString(), FileUtil.tostring(BED.a))!=null){
                            KeyGen.setTextColor(Color.GREEN);
                            //  layoutPassCode.setErrorEnabled(false);
                        }
                    } catch (Exception e) {
                        KeyGen.setTextColor(Color.RED);
                        KeyGen.setError("Enter a Valid PassCode");
                        // layoutPassCode.setErrorEnabled(true);
                        //layoutPassCode.setError("PassCode should be Greater than 32 characters");
                    }
                }
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        login.setOnClickListener(p1 -> {
            if (KeyGen.getText().toString().isEmpty()) {
                KeyGen.setTextColor(Color.RED);
                KeyGen.setError("Enter PassCode");
                // layoutPassCode.setErrorEnabled(true);
                // layoutPassCode.setError("Please enter your valid KeyGen PassCode!");
                return;
            } else if (!KeyGen.getText().toString().equalsIgnoreCase(userpassword)) {
                KeyGen.setTextColor(Color.RED);
                KeyGen.setError("Invalid PassCode");
//layoutPassCode.setErrorEnabled(true);
                //   layoutPassCode.setError("Please enter your valid KeyGen PassCode!");
                return;
            } else {
                KeyGen.setTextColor(Color.GREEN);
                //layoutPassCode.setErrorEnabled(false);
            }
           /* if(isKeyGen()){
                Intent intent = new Intent(LauncherActivity.this, MainActivity.class);
                LauncherActivity.this.startActivity(intent);
                LauncherActivity.this.finish();
            }else{
                KeyGen.setTextColor(Color.RED);
                KeyGen.setError("Invalid PassCode");
                Toast.makeText(LauncherActivity.this, "Please enter your valid KeyGen PassCode!", Toast.LENGTH_LONG).show();
            }*/
            isKeyGen();
            Intent intent = new Intent(LauncherActivity.this, MainActivity.class);
            LauncherActivity.this.startActivity(intent);
            LauncherActivity.this.finish();
        });


        /*encrypt.setOnClickListener(p1 -> startActivity(new Intent(LauncherActivity.this, Decrytion.class)));*/
    }






    private boolean isKeyGen(){
        try {
            String str = BED.De("JG+/I5f4Q294HDQmPhYSO15EEUAsP1NyDOL/0t4Is1If2Omg7oE0gw==", FileUtil.tostring(BED.a));
            assert str != null;
            if(str.equals("")|str.isEmpty()|str.length() <= 31){
                return false;
            }else{
                FileUtil.setPass(str,LauncherActivity.this);
                return true;
            }
        } catch (Exception e) {
            KeyGen.setTextColor(Color.RED);
            KeyGen.setError("Enter a Valid PassCode");
            //    layoutPassCode.setErrorEnabled(true);
            // layoutPassCode.setError("PassCode should be Greater than 32 characters");
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        LauncherActivity.this.finish();
    }

}

